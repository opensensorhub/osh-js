'use strict';

angular.module('dashboard', ['ui.bootstrap']);
